alert("Witaj na stronie");

let liczba1 = prompt("Podaj 1 liczbe:");
let liczba2 = prompt("Podaj 2 liczbe:");
wynik = Number(liczba1) + Number(liczba2);
document.write("Twój wynik to " + wynik);
