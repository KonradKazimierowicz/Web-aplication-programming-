alert("Witaj na stronie");

let imie = prompt("Podaj swoje imie","Anonim");
document.write("<h1 id='powitanie'>" + imie ,"</h1>");
console.log("cześć" + imie);